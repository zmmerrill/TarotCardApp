//
//  tarot.swift
//  Tarrot Card
//
//  Created by user914519 on 3/21/19.
//  Copyright © 2019 Zachary Merrill. All rights reserved.
//

import Foundation
import UIKit
class tarot{
    var tarotName = ""
    var tarotImage : UIImage = UIImage()
    
    
    init(tarotName tn:String) {
        tarotName = tn
    }
    init(tarotName tn:String, tarotImage img:UIImage) {
        tarotName = tn
        tarotImage = img
    }
    func getTarotImage() -> UIImage {
        return tarotImage
    }
    func getTarot() -> String {
        return tarotName
    }
}
