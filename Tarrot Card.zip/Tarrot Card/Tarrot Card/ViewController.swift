//
//  ViewController.swift
//  Tarrot Card
//
//  Created by user914519 on 3/21/19.
//  Copyright © 2019 Zachary Merrill. All rights reserved.
//

import UIKit
import AVKit
import AVFoundation

class ViewController: UIViewController {
    var someSound: AVAudioPlayer!
    @IBOutlet weak var imgT: UIImageView!
    
    @IBAction func btnOnline(_ sender: Any) {
            let app = UIApplication.shared
            let urlAddress = "https://www.tarot.com/tarot/cards/major-arcana"
            let urlw = URL(string:urlAddress)
            app.openURL(urlw!)
    }
    
    var tarotArray:[tarot]? = nil
    func InitilizeT(){
        let t0:tarot = tarot(tarotName: "0. The Fool")
        t0.tarotImage = UIImage(named:"Fool.jpg")!
        let t1:tarot = tarot(tarotName: "I. The Magician")
        t1.tarotImage = UIImage(named:"magician.jpg")!
        let t2:tarot = tarot(tarotName: "II. The High Priestess")
        t2.tarotImage = UIImage(named:"preistess.jpg")!
        let t3:tarot = tarot(tarotName: "III. The Empress")
        t3.tarotImage = UIImage(named:"Empress.jpg")!
        let t4:tarot = tarot(tarotName: "IV. The Emperor")
        t4.tarotImage = UIImage(named:"emperor.jpg")!
        let t5:tarot = tarot(tarotName: "V. The Hierophant")
        t5.tarotImage = UIImage(named:"Hierophant.jpg")!
        let t6:tarot = tarot(tarotName: "VI. The Lovers")
        t6.tarotImage = UIImage(named:"Lovers.jpg")!
        let t7:tarot = tarot(tarotName: "VII. The Chariot")
        t7.tarotImage = UIImage(named:"Chariot.jpg")!
        let t8:tarot = tarot(tarotName:"VIII. Strength")
        t8.tarotImage = UIImage(named:"Strength.jpg")!
        let t9:tarot = tarot(tarotName:"IX. The Hermit")
        t9.tarotImage = UIImage(named:"hermit.jpg")!
        let t10:tarot = tarot(tarotName:"X. Wheel of Fortune")
        t10.tarotImage = UIImage(named:"WheelOfFortune.jpg")!
        let t11:tarot = tarot(tarotName:"XI. Justice")
        t11.tarotImage = UIImage(named:"Justice.jpg")!
        let t12:tarot = tarot(tarotName:"XII. The Hanged Man")
        t12.tarotImage = UIImage(named:"hangedMan.jpg")!
        let t13:tarot = tarot(tarotName:"XIII. Death")
        t13.tarotImage = UIImage(named:"Death.jpg")!
        let t14:tarot = tarot(tarotName:"XIV. Temperance")
        t14.tarotImage = UIImage(named:"Temperance.jpg")!
        let t15:tarot = tarot(tarotName:"XV. The Devil")
        t15.tarotImage = UIImage(named:"Devil.jpg")!
        let t16:tarot = tarot(tarotName:"XVI. The Tower")
        t16.tarotImage = UIImage(named:"Tower.jpg")!
        let t17:tarot = tarot(tarotName:"XVII. The Star")
        t17.tarotImage = UIImage(named:"Star.jpg")!
        let t18:tarot = tarot(tarotName:"XVIII. The Moon")
        t18.tarotImage = UIImage(named:"Moon.jpg")!
        let t19:tarot = tarot(tarotName:"XIX. The Sun")
        t19.tarotImage = UIImage(named:"Sun.jpg")!
        let t20:tarot = tarot(tarotName:"XX. Judgement")
        t20.tarotImage = UIImage(named:"Judgment.jpg")!
        let t21:tarot = tarot(tarotName:"XI. The World")
        t21.tarotImage = UIImage(named:"World.jpg")!
        tarotArray = [t0, t1, t2, t3, t4, t5, t6, t7, t8, t9, t10, t11, t12, t13, t14, t15, t16, t17, t18, t19, t20, t21]
    }
    func getRandomTarot() -> tarot{
        let randomT = tarotArray?.randomElement()
        return randomT!
    }
    
    @IBOutlet weak var tarotTitle: UILabel!
    
    @IBAction func btnTouch(_ sender: Any) {
        let x:tarot = getRandomTarot()
        tarotTitle.text = x.getTarot()
        imgT.image = x.tarotImage
        someSound.play()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        InitilizeT()
        // Do any additional setup after loading the view, typically from a nib.
        someSound = try?
            AVAudioPlayer(contentsOf:
                URL(fileURLWithPath:Bundle.main.path(forResource: "cardPlace1", ofType: "wav")!))
    }
}

